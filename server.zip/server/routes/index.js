var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  // res.render('index', { title: 'Express' });
  console.log('Inside router get /')
  res.send("Hello")
});


// Define a route to handle GET requests
router.get('/testData', (req, res) => {
  // Process the request and send back a response
  const responseData = {
    message: 'Hello from the server!',
    data: {
      example: 'Some data to send back',
    },
  };

  // Set the appropriate headers for a JSON response
  res.setHeader('Content-Type', 'application/json');
  
  // Send the response as JSON
  res.status(200).json(responseData);
});



module.exports = router;
