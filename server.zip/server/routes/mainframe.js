const https = require('https');
const express = require('express');
const router = express.Router();
const fs = require('fs')
const path = require('path')
// const zip = require('express-zip');
const JSZip = require("jszip")
// require('dotenv').config()
const {Get,Upload, List, Delete, Rename, HMigrate, HDelete, HRecall, Create,
    CreateDataSetTypeEnum, ICreateDataSetOptions} = require("@zowe/zos-files-for-zowe-sdk");

const zowe = require('@zowe/cli')
const zowejobs = require('@zowe/zos-jobs-for-zowe-sdk')
const {SubmitJobs} = require('@zowe/zos-jobs-for-zowe-sdk');
const IssueTso = require("@zowe/zos-tso-for-zowe-sdk").IssueTso;
const ProfileInfo = require("@zowe/imperative");


let autoSpaceCards = require('../data/autoSpaceData.js');
let querySpaceCards = require('../data/querySpaceData.js');
// let dbc = require('../data/connection.js');
let connectToServer = require('../data/connection.js').connectToServer;
let insertSingleDocument = require('../data/connection.js').insertSingleDocument;
let getSingleDocument = require('../data/connection.js').getSingleDocument;
let getManyDocuments = require('../data/connection.js').getManyDocuments;
// import {connectToServer, insertSingleDocument, getSingleDocument } from '../data/connection.js';

let userTSO = process.env.MF_USER_TSO;
let paramsTSO = {};
const hostname = process.env.MF_HOST;
const port = process.env.MF_PORT;
const user = process.env.MF_USER_ZOS;
const password = process.env.MF_PASSWORD;
/*const profile = {
    hostname, port, user, password, rejectUnauthorized: false
}*/
const profile = {
    host: process.env.MF_HOST, port: process.env.MF_PORT, user: process.env.MF_USER_ZOS, password: process.env.MF_PASSWORD, rejectUnauthorized: false
};

console.log("Attempting to connect to DB...");
connectToServer();
const submittedJobsColl = "SubmittedJobs";

// Common Functions

/* GET home page. */
router.get('/', function(req, res) {const responseData = {
    message: 'Hello from the server!',
    data: {
      example: 'Some data to send back',
    },
  };

  // Set the appropriate headers for a JSON response
  res.setHeader('Content-Type', 'application/json');
  
  // Send the response as JSON
  res.status(200).json(responseData);
   
});

// Testing space - all the codes inside this part is for testing purpose only //
router.get('/testdata', (req, res) => {
    // Process the request and send back a response
    const responseData = {
      message: 'Hello from the server!',
      data: {
        example: 'Some data to send back',
      },
    };
  
    // Set the appropriate headers for a JSON response
    res.setHeader('Content-Type', 'application/json');
    
    // Send the response as JSON
    res.status(200).json(responseData);
  });
  


router.get('/getFileData2', async (req, res) => {
    console.log('Inside MF router get /getFileData2');
    // console.log("req.body: ", req.body);
    console.log("req.trishabody: ", req.query.fileName);
    console.log("req.trishamember: ", req.query.fileName);
    
    let command = `ex 'SYSSHR.ZOOPS.CLIST(FREAD)' 'SYSSHR.ZOOPS.ZS'`;
    try {
        const sessCfg = zowe.ZosmfSession.createSessCfgFromArgs(profile);
        const sessCfgWithCreds = await ProfileInfo.ConnectionPropsForSessCfg.addPropsOrPrompt(sessCfg, profile);
        const session = new ProfileInfo.Session(sessCfgWithCreds);
        Get.dataSet(session, req.query.fileName).then((val) => {
            res.status(201).send(val.toString());
            console.log("Response from RESHMIKA",val.toString())},(reason) => {
              res.status(201).json({message: 'Invalid or No response from Mainframe :'+reason});
              console.log("PRINTING REASON",reason);
        })
        // let response = await IssueTso.issueTsoCommand(session, userTSO, command, paramsTSO);
        // //console.log(response)
        // if (response && response.success) {
        //     let responseStr = response.commandResponse;
        //  //   console.log(responseStr);
        //     if (!responseStr || responseStr.length == 0) {
        //         res.status(201).json({message: 'Invalid or No response from Mainframe'});
        //     }
        //  //   console.log(responseStr);
        //     try {
        //         res.status(201).send(responseStr);
        //     } catch (error) {
        //         console.log(error);
        //         res.status(201).json({message: 'Invalid JSON format from Mainframe'});
        //     }
        // } else {
        //     res.status(201).json({message: 'Invalid or No response from Mainframe'});
        // }
    } catch (err) {
        console.log(err)
        res.status(500).json(err);
    }
});
//adding the below code for automation space => smf viewer

module.exports = router;

