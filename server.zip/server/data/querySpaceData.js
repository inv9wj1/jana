const autoSpaceCards = [
  {
      "id": "1",
      "type": "Automation",
      "title": "MQOD",
      "content": "",
    //   "date": "2018-01-01",
      "image": "https://picsum.photos/494/150",
      "inputData": [
          {
              "name": "input1",
              "label": "Total pages",
              "responsetype": "text",
              "required": true,
              "defaultvalue": "default value"
          },
          {
              "name": "input2",
              "label": "Unused pages",
              "responsetype": "text",
              "required": true,
              "defaultvalue": "default value"
          },
    {
              "name": "input3",
              "label": "Persitent data pages",
              "responsetype": "text",
              "required": true,
              "defaultvalue": "default value"
          },
     {
              "name": "input4",
              "label": "Non persistent data pages",
              "responsetype": "text",
              "required": true,
              "defaultvalue": "default value"
          },
          {
            "name": "input5",
            "label": "Expansion count",
            "responsetype": "text",
            "required": true,
            "defaultvalue": "default value"
        }
      ],
      "commandToExecuteInMF": "ex test.clist(sojob1) 'input1 input2 input3 input4'" ,
  },
  {
      "id": "2",
      "type": "Automation",
      "title": "MQ1D",
      "content": "",
    //   "date": "2018-01-01",
      "image": "https://picsum.photos/495/150",
      "inputData": [
          {
              "name": "input1",
              "label": "Enter systemname",
              "responsetype": "text",
              "required": true,
              "defaultvalue": "default value"
          },
          {
              "name": "input2",
              "label": "Enter Report/healthchk name",
              "responsetype": "text",
              "required": true,
              "defaultvalue": "default value"
          },
    {
              "name": "input3",
              "label": "Enter tablespace name",
              "responsetype": "text",
              "required": true,
              "defaultvalue": "default value"
          }
      ],
      "commandToExecuteInMF": "ex test.clist(sojob2) 'input1 input2 input3'",
  },
  {
      "id": "3",
      "type": "Automation",
      "title": "MQ2D",
      "content": "",
    //   "date": "2018-01-01",
      "image": "https://picsum.photos/496/150",
      "inputData": [
          {
              "name": "input1",
              "label": "Enter System name",
              "responsetype": "text",
              "required": true,
              "defaultvalue": "default value"
          },
          {
              "name": "input2",
              "label": "Enter UPDATE/ALTER/QUERY",
              "responsetype": "text",
              "required": true,
              "defaultvalue": "default value"
          },
    {
              "name": "input3",
              "label": "Enter Queue name",
              "responsetype": "text",
              "required": true,
              "defaultvalue": "default value"
          }
      ],
      "commandToExecuteInMF": "ex z44168.test.clist(sojob3) 'input1 input2 input3'",
  },
  {
      "id": "4",
      "type": "Automation",
      "title": "MQ3D",
      "content": "",
    //   "date": "2018-01-01",
      "image": "https://picsum.photos/497/150",
      "inputData": [
          {
              "name": "input1",
              "label": "Enter APF/LNKLST/LLA",
              "responsetype": "text",
              "required": true,
              "defaultvalue": "default value"
          },
          {
              "name": "input2",
              "label": "Enter UPDATE/ADD/QUERY",
              "responsetype": "text",
              "required": true,
              "defaultvalue": "default value"
          },
    {
              "name": "input3",
              "label": "Queue name",
              "responsetype": "text",
              "required": true,
              "defaultvalue": "default value"
          }
      ],
      "commandToExecuteInMF": "ex z44168.test.clist(sojob4) 'input1 input2 input3'",
  },
  {
      "id": "5",
      "type": "Automation",
      "title": "MQ4D",
      "content": "",
    //   "date": "2018-01-01",
      "image": "https://picsum.photos/498/150",
      "inputData": [
          {
              "name": "input1",
              "label": "Enter Application name",
              "responsetype": "text",
              "required": true,
              "defaultvalue": "default value"
          },
          {
              "name": "input2",
              "label": "Enter Jobname",
              "responsetype": "text",
              "required": true,
              "defaultvalue": "default value"
          },
          {
              "name": "input3",
              "label": "Enter WS id",
              "responsetype": "text",
              "required": true,
              "defaultvalue": "default value"
          },
    {
              "name": "input4",
              "label": "Enter anyone option SUBMIT/QUERY/RESTART/Special RESOURCES/FC",
              "responsetype": "text",
              "required": true,
              "defaultvalue": "default value"
          }
      ],
      "commandToExecuteInMF": "ex z44168.test.clist(sojob5) 'input1 input2 input3 input4'",
  },
  {
      "id": "6",
      "type": "Automation",
      "title": "MQ7S",
      "content": "",
    //   "date": "2018-01-01",
      "image": "https://picsum.photos/500/150",
      "inputData": [
          {
              "name": "input1",
              "label": "GPD202",
              "responsetype": "text",
              "required": true,
              "defaultvalue": "SOJOB"
          },
		  {
              "name": "input2",
              "label": "ORG 406",
              "responsetype": "text",
              "required": true,
              "defaultvalue": "SOJOB"
          },
		  {
              "name": "input3",
              "label": "SCHEME",
              "responsetype": "text",
              "required": true,
              "defaultvalue": "SOJOB"
          },
		  {
              "name": "input4",
              "label": "OWNING BRANCH",
              "responsetype": "text",
              "required": true,
              "defaultvalue": "SOJOB"
          },
		  {
              "name": "input5",
              "label": "SEG ID",
              "responsetype": "text",
              "required": true,
              "defaultvalue": "SOJOB"
          },
		  {
              "name": "input6",
              "label": "LMS ACCOUNT NUMBER",
              "responsetype": "text",
              "required": true,
              "defaultvalue": "SOJOB"
          },
		   {
              "name": "input7",
              "label": "MQ9D",
              "responsetype": "text",
              "required": true,
              "defaultvalue": "SOJOB"
          },
      ],
      "commandToExecuteInMF": "ex 'z44168.test.clist(soops)' 'input1'",
  }
]

module.exports = autoSpaceCards;
