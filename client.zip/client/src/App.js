
import './App.css';
import axiosConnect from './api/axiosConnect';

function App() {
  const loadFileSpaceData = () => {
    //const res = await axiosConnect.get("/getFileSpaceData",{"fileDir": searchInput});
    console.log('method calling....');
    // axiosConnect.get('/getFileData2', {"fileName":"SYSSHR.ZOOPS.TPS1"})
    axiosConnect.get('/getFileData2', {
        params: {
            fileName: "SYSEIM.OPSMVS.IPLCHECK.IVPS.ERRMSG.TPLA"
        }
    })
    .then(response => {
        //handle success
        console.log(response);
        console.log("Data received from getFileSpaceData: " + response.data);
        // Additional logic for handling the response data
        // ...

        // Make sure to handle loading in both success and error cases
        // handleOnLoading(false);
    })
    .catch(err => {
        //handle error
        console.log(err);
        // setCommandOutput("Error while getting the Files Directory: " + fullCommand);
        // handleOnLoading(false);
    });
};



  return (
    <div className="App">
   <button onClick={loadFileSpaceData}>Call My Method</button>
    </div>
  );
}
export default App;
